path={'\spambase\train.txt','\spambase\test.txt'};
X=load(path{1})
Y=load(path{2})
